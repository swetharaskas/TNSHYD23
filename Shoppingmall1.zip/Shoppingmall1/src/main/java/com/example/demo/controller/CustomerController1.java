package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Customer1;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.CustomerRepository1;
@RestController
@RequestMapping("/api/v1/")
public class CustomerController1 {
	@Autowired
	private CustomerRepository1 repository;
	
	// get all employees
		@GetMapping("/customer")
		public List<Customer1> getAllCustomers(){
			return repository.findAll();
		}		
		
		// create employee rest api
		@PostMapping("/customer")
		public Customer1 createCustomer(@RequestBody Customer1 customer) {
			return repository.save(customer);
		}
		
		// get employee by id rest api
		@GetMapping("/customer/{id}")
		public ResponseEntity<Customer1> getCertificateById(@PathVariable Long id) {
			Customer1 customer = repository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Customer not exist with id :" + id));
			return ResponseEntity.ok(customer) ;
		}
		// update employee rest api
		
		@PutMapping("/customer/{id}")
		public ResponseEntity<Customer1> updateCustomer(@PathVariable Long id, @RequestBody Customer1 customerDetails){
			Customer1 customer = repository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("Customer not exist with id :" + id));
			
			
			customer.setPhone(customerDetails.getPhone());
			customer.setEmail(customerDetails.getEmail());
			
			Customer1 updatedCustomer = repository.save(customer);
			return ResponseEntity.ok(updatedCustomer);
		}
		
		// delete employee rest api
		@DeleteMapping("/customer/{id}")
		public ResponseEntity<Map<String, Boolean>> deleteCustomer(@PathVariable Long id){
			Customer1 customer = repository.findById(id)
					.orElseThrow(() -> new ResourceNotFoundException("customer not exist with id :" + id));
			
			repository.delete(customer);
			Map<String, Boolean> response = new HashMap<>();
			response.put("deleted", Boolean.TRUE);
			return ResponseEntity.ok(response);
		}

}
